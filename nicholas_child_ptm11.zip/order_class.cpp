
/***********************************************************************************
*************************************
Name:  Nick Child        Z#: Z23537683
Course: Foundations of Computer Science (COP3014)
Professor: Dr. Lofton Bullard
Due Date:  11/18/2019          Due Time: 11:59 PM
Total Points: 20
Assignment #: amazon_porders11.cpp
Description: A implentation containing the code for the class
***********************************************************************************
**************************************/
#include <iostream>
#include <string>
#include <fstream>
#include "order_class.h"
using namespace std;
/***********************************************************************************
************************************************
//Name: default constructor
//Precondition: nothing is initiated
//Postcondition: 
//Decription: Reads the data file of purchase order information (cell number, item,
quantity, price, and processing plant) into the dynamic array of order records, 
//INV. If the count become equal to the size the function double_size is called and
the memory allocated to INV is doubled.
***********************************************************************************
*************************************************/
order_class::order_class()
{
	cout << "The default constructor has been called\n";
	count = 0;
	size = 1;
	INV = new order_record[size];
	ifstream in;
	in.open("purchase_data.txt");
	while (!in.eof())
	{
	if (is_full())
	{
	double_size();
	}
	in >> INV[count].cell_number >> INV[count].item_number>>INV[count].quantity>>INV[count].price>>INV[count].processing_plant;
	count++;
	}
	in.close();
}
/***********************************************************************************
************************************************
//Name: copy constructor
//Precondition: nothing is initiated
//Postcondition: 
//Decription: Reads the data file of purchase order information (cell number, item,
quantity, price, and processing plant) into the dynamic array of order records, 
//INV. If the count become equal to the size the function double_size is called and
the memory allocated to INV is doubled.
***********************************************************************************
*************************************************/
order_class::order_class(const order_class & org){

       cout << "copy constructor has been called automatically by the compiler\n";
        count = org.count;
        size = org.size;  //set "capacity" equal to org's capacity
        INV = new order_record[size];  //allocation of  memory for the dynamic array A is equal to the amount of org's memory

        for (int i = 0; i < count; i++)  //copy contents of org's dynamic array into the current object's dynamic array
        {
                INV[i] = org.INV[i];
        }


}

/***********************************************************************************
**********************************************
Name: is_Empty 
Precondition: count is initialized

Postcondition: count is still initialized

Decription: returns true if INV is empty
/
***********************************************************************************
**********************************************/
bool order_class::is_Empty()
{
return count == 0;
}
/***********************************************************************************
***********************************************/
//Name: Is_full 
//Precondition: count and size are initialized
//Postcondition: count and size are still initialized
//Decription: returns true if INV is full
/***********************************************************************************
**********************************************/
bool order_class::is_full()
{
return count == size;
}
/************************************************************************************

//Name: search
//Precondition: everything initialized
//Postcondition: everyhting initialized
//Decription: locates key in INV if it is there; otherwise -1 is returned
***********************************************/
int order_class::search(const string key)
{
	for (int i=0;i<count;i++){
				if(INV[i].cell_number==key)return i;
		}
	return -1;
}
/***********************************************************************************
**********************************************
//Name: add
//Precondition: INV count and size initialized
//Postcondition: same
//Decription: adds a new record to INV; if INV is full, double_size is called to increase the capacity of INV.
***********************************************************************************
*********************************************/
void order_class::add()
{
	if (count==size)double_size();
	cout<<"Enter cell number"<<endl;
	cin >> INV[count].cell_number;
	cout<<"Enter item number" <<endl;
	cin>> INV[count].item_number;
	cout<<"Enter quantity"<<endl;
	cin>>INV[count].quantity;
	cout<<"Enter price"<<endl;
	cin>>INV[count].price;
	cout<<"Enter processing_plant"<<endl;
	cin>>INV[count].processing_plant;
	count++;
	process();
}
/***********************************************************************************
*********************************************
/Name: Remove
//Precondition: INV count and size initialized
//Postcondition: same 
//Decription:removes all order records in INV with a cell number field that 
matches key, if it is there. Chain was
//            implemented
***********************************************************************************
********************************************/
order_class & order_class::operator-(const string key)
{
	int loc = this->search(key);
	if(loc==-1)cout<<"Nothing to Remove"<<endl;
	while(loc!=-1)
	{
		for(int j=loc; j<count-1; j++)
		{
			INV[j] = INV[j+1];
		}
	count--;
	loc=search(key);
	} return *this;
}

/***********************************************************************************
*****************************************
//Name: operator<<
//Precondition: 
//Postcondition: 
//Decription: prints every field of every call_record in INV formatted to the 
screen.
/
***********************************************************************************
****************************************/

ostream & operator<<(ostream & out, order_class & Org) //prints all the elements in INV to the screen
{
	out.setf(ios::fixed);
	out.setf(ios::showpoint);
	out.precision(2);
	
	for(int i=0; i<Org.count; i++)// do not use SIZE
	{
	    out << Org.INV[i].cell_number << "\t"<<Org.INV[i].item_number<< "\t"<<Org.INV[i].quantity<< "\t"<<Org.INV[i].price<< "\t"<<Org.INV[i].processing_plant<< "\t"<<Org.INV[i].tax_rate<< "\t"<<Org.INV[i].order_tax<< "\t"<<Org.INV[i].net_cost<< "\t"<<Org.INV[i].total_cost<<endl;
		
	}
	
return out;
}
/***********************************************************************************
*******************************************/
//Name: double_size
//Precondition: INV count and size initialized
//Postcondition: same
//Decription: doubles the size (capacity) of INV
/***********************************************************************************
*******************************************/
void order_class::double_size( )
{
size *=2;
order_record *temp = new order_record[size];
for(int i=0; i<count; i++)
{
temp[i] = INV[i];
}
delete [ ] INV;
INV = temp;
}
/***********************************************************************************
*******************************************
//Name: process
//Precondition: cell_number, item_number, quantity, price, and processing_plant 
// tax_rate, tax_cost, net_cost, and total_cost not initialized.
//Postcondition: all variables are now initialized
//Decription: calculate the net cost, tax rate, order tax and total cost for every order record in INV.
void process(order_record * INV, int count)
***********************************************************************************
******************************************/
void order_class::process()
{
	for(int i=0;i<count;i++){
		if(INV[i].processing_plant<=50)
			INV[i].tax_rate=0.06;
		else if(INV[i].processing_plant<=110)
            INV[i].tax_rate=0.07;
        else if(INV[i].processing_plant<=200)
            INV[i].tax_rate=0.08;
        else if(INV[i].processing_plant<=500)
            INV[i].tax_rate=0.09;
        else INV[i].tax_rate=0.11;



	       
		INV[i].order_tax=INV[i].quantity*INV[i].price*INV[i].tax_rate;

		INV[i].net_cost=INV[i].quantity*INV[i].price;
		INV[i].total_cost=INV[i].net_cost+INV[i].order_tax;

	}
}

/***********************************************************************************
*****************************************
//Name: destructor
//Precondition: 
//Postcondition: Nothing is initialized
//Decription: de-allocates all memory allocated to INV.  This will be the last 
function to be called (automatically by the compiler)
//before the program is exited.
/
***********************************************************************************
****************************************/
order_class::~order_class()
{
cout << "The destructor has been called\n";
delete[] INV;

}