
/***********************************************************************************
*************************************
Name:  Nick Child        Z#: Z23537683
Course: Foundations of Computer Science (COP3014)
Professor: Dr. Lofton Bullard
Due Date:  11/18/2019          Due Time: 11:59 PM
Total Points: 20
Assignment #: amazon_porders11.cpp
Description: A header file to declare the order class and order record class
***********************************************************************************
**************************************/
#ifndef ORDER_CLASS_H
#define ORDER_CLASS_H
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

class order_record
{
	public:
	string cell_number;
	string item_number;
	double quantity;
	double price;
	int processing_plant;
	double tax_rate;
	double order_tax;
	double net_cost;
	double total_cost;
};
class order_class
{
		public:
		order_class();
		order_class(const order_class &);//copy constructor
		~order_class(); //de-allocates all memory allocate to INV by operator new.
		bool is_Empty(); //inline implementation
		bool is_full();//inline implementation
		int search(const string key);//returns location if item in INV; otherwise 
		void add(); //adds a order record to INV
		void double_size();
		void process();
		void print(); //prints all the elements in INV to the screenprivate:
		friend ostream & operator<<(ostream & out, order_class & Org);
		order_class & operator-(const string key);//removes all items in INV with a cell number that matches key.
		private:
			int count;
		int size;
		order_record *INV;
};
#endif