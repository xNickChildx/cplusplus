/***********************************************************************************
*************************************
Name:  Nick Child        Z#: Z23537683
Course: Foundations of Computer Science (COP3014)
Professor: Dr. Lofton Bullard
Due Date:  11/13/2019          Due Time: 11:59 PM
Total Points: 20
Assignment #: amazon_porder98.cpp
Description:The driver for the assignment
***********************************************************************************
**************************************/
#include <iostream>
#include <string>
#include <fstream>
#include "order_class.h"
using namespace std;


//Here is your driver to test the program
int main()
{
order_class myOrders;//declaring order_class object myOrders; the default constructor is called automically.
cout << "**********************************************************************\n";
//Test 1:
cout << "Test 1: Testing default construcor, double_size, process, is_full and print " << endl;
myOrders.process( );
cout<<myOrders;
cout << "End of Test 1" << endl;
cout << "**********************************************************************\n";
cout << "**********************************************************************\n";
//Test 2:
//void add();
cout << "Test 2: Testing add, double_size, process, is_full, and print " << endl;
myOrders.add( );
cout<<myOrders;
cout << "End of Test 2" << endl;
cout << "**********************************************************************\n";
cout << "**********************************************************************\n";
//Test 3:
//void remove(string key);
cout << "Test 3: Testing remove, is_Empty, search and print " << endl;
cout << "Removing 954632155, 7877176590, and 3051234567\n";
myOrders - "9546321555" - "7877176590" - "3051234567";
cout<<myOrders;
cout << "Removing 9546321555 ---AGAIN--- SHOULD GET MESSAGE\n";
myOrders - "9546321555";
cout<<myOrders;
cout << "End of Test 3" << endl;
cout << "**********************************************************************\n";
cout << "**********************************************************************\n";
cout << "Test4: Testing copy constructor\n\n";
order_class yourOrders = myOrders;
cout << yourOrders << endl;
cout << "End of Test 4" << endl;
cout << "**********************************************************************\n";
cout << "**********************************************************************\n";
cout << "Test 5: Destructor called" << endl;
cout << "End of Test 5" << endl;
cout << "**********************************************************************\n";
cout << "**********************************************************************\n";
return 0;
}

